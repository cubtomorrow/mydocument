package com.jt.sys.service;

import com.jt.sys.entity.SysConfig;

public interface SysConfigService {

	   SysConfig findById(Integer id);
}
