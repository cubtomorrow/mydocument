package com.test;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.Test;
import org.mybatis.spring.SqlSessionFactoryBean;

import com.jt.sys.dao.SysConfigDao;
import com.jt.sys.entity.SysConfig;
public class TestBeans01 extends TestBase {
	 @Test
	 public void testSqlSessionFactory(){
		 SqlSessionFactory ssf=
		 ctx.getBean("sqlSessionFactory",SqlSessionFactory.class);
		 System.out.println(ssf);
		 //=======================(下面的了解)
		 SqlSessionFactoryBean ssfb=
		 ctx.getBean("&sqlSessionFactory",
				 SqlSessionFactoryBean.class);
		 System.out.println(ssfb);
	 }
	 @Test
	 public void testSysConfigDao01(){
		 SqlSessionFactory ssf=
		 ctx.getBean("sqlSessionFactory",SqlSessionFactory.class);
		 SqlSession session=ssf.openSession();
		 SysConfigDao dao=
		 session.getMapper(SysConfigDao.class);
		 SysConfig config=dao.findById(4);//mybatis自动完成映射操作(反射)
		 System.out.println(config.getName());
		 session.close();
	 }
	 
}
