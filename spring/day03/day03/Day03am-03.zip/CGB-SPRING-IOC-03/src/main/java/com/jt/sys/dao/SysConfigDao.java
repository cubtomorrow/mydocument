package com.jt.sys.dao;

import com.jt.sys.entity.SysConfig;

public interface SysConfigDao {//SysConfigMapper.xml
	 SysConfig findById(Integer id);
}
