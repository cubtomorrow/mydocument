package com.jt.sys.dao.impl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.sql.DataSource;

import com.jt.sys.dao.SysConfigDao;
import com.jt.sys.entity.SysConfig;

public class SysConfigDaoImpl implements SysConfigDao {
	private DataSource dataSource;//ref 其它bean对象的值
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	public SysConfig findById(Integer id) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="select * from sys_configs where id=?";
		//1.获取连接
	    try{
		conn=dataSource.getConnection();
		System.out.println("conn="+conn);
		//2.创建Statement对象
		pstmt=conn.prepareStatement(sql);
		pstmt.setInt(1,id);
		//3.发送sql
		rs=pstmt.executeQuery();
		//4.处理结果
		SysConfig sysConfig=null;
		if(rs.next()){
			sysConfig=new SysConfig();
			sysConfig.setId(rs.getInt("id"));
			sysConfig.setName(rs.getString("name"));
			sysConfig.setValue(rs.getString("value"));
			//.....
		}
		return sysConfig;
	    }catch(Exception e){
	    e.printStackTrace();
	    throw new RuntimeException(e);//DaoException
	    }finally{
		//5.释放资源
	    if(rs!=null)try{rs.close();}catch(Exception e){}
	    if(pstmt!=null)try{pstmt.close();}catch(Exception e){}
	    if(conn!=null)try{conn.close();}catch(Exception e){}
	    }
	}
}
