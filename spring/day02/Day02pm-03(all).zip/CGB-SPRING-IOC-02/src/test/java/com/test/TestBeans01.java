package com.test;

import org.junit.Test;

import com.jt.sys.controller.SysConfigController;
import com.jt.sys.dao.SysConfigDao;
import com.jt.sys.entity.SysConfig;
import com.jt.sys.service.SysConfigService;

public class TestBeans01 extends TestBase{

	 @Test
	 public void testSysConfigDao(){
		 SysConfigDao dao=
		 ctx.getBean(SysConfigDao.class);
		 SysConfig config=dao.findById(4);
		 System.out.println(config.getName());
	 }
	 @Test
	 public void testSysConfigService(){
		 SysConfigService service=
				 ctx.getBean(SysConfigService.class);
		 SysConfig config=service.findById(4);
		 System.out.println(config.getName());
	 }
	 @Test
	 public void testSysConfigController(){
		 SysConfigController sc=
				 ctx.getBean(SysConfigController.class);
		 SysConfig config=sc.doFindById(4);
		 System.out.println(config.getName());
	 }
}




