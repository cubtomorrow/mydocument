package com.jt.sys.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;

import com.jt.sys.service.SysConfigService;

/**
 * @Controller 注解一般用于修饰控制层对象
 * 告诉spring这个类由它管理
 * @author 速度
 */
@Controller
public class SysConfigController {
  /**
   * @Autowired 注解修饰属性时
   * 用于告诉spring从容器中按属性
   * 类型查找对应的Bean对象为属性赋值.
   */
  @Autowired
  private SysConfigService sysConfigService;
 
  public SysConfigService getSysConfigService() {
	return sysConfigService;
  }
}





