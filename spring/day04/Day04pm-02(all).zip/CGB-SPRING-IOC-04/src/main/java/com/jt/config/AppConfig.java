package com.jt.config;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;

import com.alibaba.druid.pool.DruidDataSource;
/**
 * 通过此类取代spring-configs.xml中的配置
 * @author 速度
 */
@ComponentScan("com.jt") 
@PropertySource("classpath:configs.properties")
//<context:component-scan base-package="com.jt"/>
public class AppConfig {
	/**整合第三方bean对象时可以采用如下方式*/
	@Bean(value="dataSource",initMethod="init",destroyMethod="close") //<bean id="" class=""/>
	@Lazy(false)
	@Scope("singleton")
	public DataSource newDruidDataSource(
		@Value("${jdbcDriver}")String driver,
		@Value("${jdbcUrl}")String url,
		@Value("${jdbcUser}")String user,
		@Value("${jdbcPassword}")String password){
	    //构建对象
		DruidDataSource ds = new DruidDataSource();
		//为对象属性赋值
		ds.setDriverClassName(driver);
		ds.setUrl(url);
		ds.setUsername(user);
		ds.setPassword(password);
		return ds;
	}
	  
}


