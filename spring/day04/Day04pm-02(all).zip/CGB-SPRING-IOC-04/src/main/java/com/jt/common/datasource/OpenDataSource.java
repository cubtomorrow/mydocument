package com.jt.common.datasource;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
/**
 * 通过Component注解描述
 * 此对象是一个普通的Bean对象
 */
@Component("dataSource")//Component.class
@Scope("singleton")//Scope.class
//默认,假如需要是多例可设置为prototype
@Lazy(true) //默认延迟加载,假如希望立刻加载可设置为false
public class OpenDataSource {
	  /***
	   * 生命周期初始化方法
	   */
      @PostConstruct //jdk1.7
	  public void init(){
		  System.out.println("init");
	  }
      /**生命周期销毁方法*/
      @PreDestroy //jdk1.7
	  public void close(){
		  System.out.println("close");
	  }
}





