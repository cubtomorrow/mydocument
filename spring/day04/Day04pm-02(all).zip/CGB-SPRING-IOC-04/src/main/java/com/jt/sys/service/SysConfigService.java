package com.jt.sys.service;

public interface SysConfigService {

}
