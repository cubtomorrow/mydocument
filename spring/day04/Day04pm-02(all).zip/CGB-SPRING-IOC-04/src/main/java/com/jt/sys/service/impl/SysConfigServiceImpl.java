package com.jt.sys.service.impl;
import org.springframework.stereotype.Service;
import com.jt.sys.service.SysConfigService;
/**
 * service注解一般用于修饰业务层对象
 * 告诉spring框架这个类由spring管理
 * @author 速度
 */
@Service
public class SysConfigServiceImpl 
       implements SysConfigService {

}
