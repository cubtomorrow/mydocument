package com.test;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.junit.Test;

import com.jt.common.datasource.OpenDataSource;
import com.jt.sys.service.SysConfigService;
public class TestBeans02 extends TestBase02 {
	  @Test
	  public void testOpenDataSource(){
		  OpenDataSource ds=
		  ctx.getBean(OpenDataSource.class);
		  System.out.println(ds);
	  }
	  @Test
	  public void testSysConfigService(){
		  SysConfigService service=
		  ctx.getBean("sysConfigServiceImpl",SysConfigService.class);
	      System.out.println(service);
	  }
	  @Test
	  public void testDruidDataSource() throws SQLException{
		  DataSource ds=
		  ctx.getBean("dataSource",
				  DataSource.class);
		  System.out.println(ds.getConnection());
	  }
}







