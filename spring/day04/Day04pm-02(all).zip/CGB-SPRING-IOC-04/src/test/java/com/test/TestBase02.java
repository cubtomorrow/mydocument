package com.test;
import org.junit.After;
import org.junit.Before;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.jt.config.AppConfig;

public class TestBase02 {
	protected AnnotationConfigApplicationContext ctx;
	@Before
	public void init(){
		//基于注解配置类初始化spring容器
		ctx = new AnnotationConfigApplicationContext(
		AppConfig.class);//Class
	}
	@After
	public void destory(){
		ctx.close();
	}
}
