package com.test;
import org.junit.Test;
import com.jt.common.datasource.OpenDataSource;
import com.jt.sys.controller.SysConfigController;
import com.jt.sys.service.SysConfigService;
public class TestBeans01 extends TestBase01{
	 @Test
	 public void testOpenDataSouce(){
		OpenDataSource ds=
		ctx.getBean("dataSource",
		OpenDataSource.class);
		System.out.println(ds);
	 }
	 @Test
	 public void testSysConfigService(){
		 SysConfigService service=
		 ctx.getBean("sysConfigServiceImpl",
		 SysConfigService.class);
		 System.out.println(service);
	 }
	 
	 @Test
	 public void testSysConfigController(){
		 SysConfigController c=
		 ctx.getBean("sysConfigController",
		 SysConfigController.class);
		 System.out.println(c);
		 System.out.println(c.getSysConfigService());
	 }
	 
	 
	 
	 
}
