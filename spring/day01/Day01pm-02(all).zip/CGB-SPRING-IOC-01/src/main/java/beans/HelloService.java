package beans;

public class HelloService {
	 public HelloService() {
		 System.out.println("helloService()");
	 }
	 public void sayHello(){
		 System.out.println("helloworld");
	 }
}
