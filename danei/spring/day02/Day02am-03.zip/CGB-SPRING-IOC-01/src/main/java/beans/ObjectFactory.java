package beans;
/***
 * 假设这是一个工厂对象
 * 例如SqlSessionFactory
 * @author 速度
 */
public class ObjectFactory {

}
