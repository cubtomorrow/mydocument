package beans;
/**假定这是一个数据源对象*/
public class OpenDataSource {
	 public OpenDataSource() {
		System.out.println("OpenDataSource()");
	 }
	 public void init(){
		 System.out.println("init()");
	 }
	 public void getConnection(){
		 System.out.println("getConnection()");
	 }
	 public void close(){
		 System.out.println("close()");
	 }
}
