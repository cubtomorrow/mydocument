package com.jt.sys.dao.impl;
import java.sql.Connection;

import javax.sql.DataSource;

import com.jt.sys.dao.SysConfigDao;

public class SysConfigDaoImpl 
             implements SysConfigDao {
	
	private DataSource dataSource;//ref 其它bean对象的值
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	public void findById(Integer id) {
		Connection conn=null;
		//1.获取连接
	    try{
		conn=dataSource.getConnection();
		System.out.println("conn="+conn);
		//2.创建Statement对象
		//3.发送sql
		//4.处理结果
	    }catch(Exception e){
	    e.printStackTrace();	
	    }finally{
		//5.释放资源
	    }
	}
}
