package com.jt.sys.dao;
public interface SysConfigDao {
	  void findById(Integer id);
}
