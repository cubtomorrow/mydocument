package com.test;

import org.junit.Test;

import com.jt.sys.dao.SysConfigDao;

public class TestBeans01 extends TestBase{

	 @Test
	 public void testSysConfigDao(){
		 SysConfigDao dao=
		 ctx.getBean(SysConfigDao.class);
		 dao.findById(4);
	 }
}




