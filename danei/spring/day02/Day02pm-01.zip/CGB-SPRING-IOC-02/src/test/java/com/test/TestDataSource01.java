package com.test;
import java.sql.Connection;

import org.junit.Test;

import com.alibaba.druid.pool.DruidDataSource;
import com.mchange.v2.c3p0.ComboPooledDataSource;
public class TestDataSource01 extends TestBase {
	@Test
	public void testC3p0DataSource()
	throws Exception{
		//1.获取数据源对象
		ComboPooledDataSource ds1=
		ctx.getBean("c3p0DataSource",
		ComboPooledDataSource.class);
		//2.通过数据源对象获取连接
		Connection conn=ds1.getConnection();
		System.out.println("conn="+conn);
	}
	@Test
	public void testDruidDataSource()
			throws Exception{
		//1.获取数据源对象
		DruidDataSource ds1=
		ctx.getBean("druidDataSource",
			DruidDataSource.class);
		//2.通过数据源对象获取连接
		Connection conn=ds1.getConnection();
		System.out.println("conn="+conn);
	}
}
