package com.test;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.Test;
import org.mybatis.spring.SqlSessionFactoryBean;

import com.jt.sys.controller.SysConfigController;
import com.jt.sys.dao.SysConfigDao;
import com.jt.sys.entity.SysConfig;
import com.jt.sys.service.SysConfigService;
public class TestBeans01 extends TestBase {
	 @Test
	 public void testSqlSessionFactory(){
		 SqlSessionFactory ssf=
		 ctx.getBean("sqlSessionFactory",SqlSessionFactory.class);
		 System.out.println(ssf);
		 //=======================(下面的了解)
		 SqlSessionFactoryBean ssfb=
		 ctx.getBean("&sqlSessionFactory",
				 SqlSessionFactoryBean.class);
		 System.out.println(ssfb);
	 }
	 @Test
	 public void testSysConfigDao01(){
		 SqlSessionFactory ssf=
		 ctx.getBean("sqlSessionFactory",SqlSessionFactory.class);
		 SqlSession session=ssf.openSession();
		 SysConfigDao dao=
		 session.getMapper(SysConfigDao.class);
		 SysConfig config=dao.findById(4);//mybatis自动完成映射操作(反射)
		 System.out.println(config.getName());
		 session.close();
	 }
	 @Test
	 public void testSysConfigDao02(){
		 SysConfigDao dao=
		 ctx.getBean("sysConfigDao",SysConfigDao.class);
		 SysConfig config=dao.findById(4);//mybatis自动完成映射操作(反射)
		 System.out.println(config.getName());
	 }
	 @Test
	 public void testSysConfigService(){
		 SysConfigService sysConfigService=
		 ctx.getBean(SysConfigService.class);
		 SysConfig cfg=
		 sysConfigService.findById(4);
		 System.out.println(cfg.getName());
	 }
	 @Test
	 public void testSysConfigController(){
		 SysConfigController sysConfigController=
		 ctx.getBean(SysConfigController.class);
		 SysConfig cfg=
		 sysConfigController.doFindById(4);
		 System.out.println(cfg.getName());
	 }
	 
}
