package com.jt.sys.service.impl;
import java.util.logging.Logger;
import com.jt.sys.dao.SysConfigDao;
import com.jt.sys.entity.SysConfig;
import com.jt.sys.service.SysConfigService;
public class SysConfigServiceImpl implements SysConfigService {//Class
	//JDK中的日志API对象
	private  Logger log=
    Logger.getLogger(
    SysConfigServiceImpl.class.getName());
	private SysConfigDao sysConfigDao;
	public void setSysConfigDao(SysConfigDao sysConfigDao) {
		this.sysConfigDao = sysConfigDao;
	}
	public SysConfig findById(Integer id) {
		long startTime=System.nanoTime();
		//1.验证参数的有效性
		if(id==null||id<1)
		throw new IllegalArgumentException("id值无效");
		//2.执行数据查询
		SysConfig cfg=sysConfigDao.findById(id);
		//3.验证结果
		if(cfg==null)
		throw new RuntimeException("记录可能已经不存在");
		long totalTime=System.nanoTime()-startTime;
		log.info("totleTime="+totalTime);
		//4.返回结果
		return cfg;
	}

}
