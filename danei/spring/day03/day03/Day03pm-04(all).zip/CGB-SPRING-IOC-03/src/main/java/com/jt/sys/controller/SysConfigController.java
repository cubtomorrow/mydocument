package com.jt.sys.controller;

import com.jt.sys.entity.SysConfig;
import com.jt.sys.service.SysConfigService;


public class SysConfigController {

    private SysConfigService sysConfigService;
    public void setSysConfigService(SysConfigService sysConfigService) {
		this.sysConfigService = sysConfigService;
	}
	public SysConfig doFindById(Integer id){
		return sysConfigService.findById(id);
	} 
	
}//W(When)W(What)W(Where)W(Why)+h(How)
