package com.jt.sys.dao.impl;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import com.jt.sys.dao.SysConfigDao;
import com.jt.sys.entity.SysConfig;
public class SysConfigDaoImpl implements SysConfigDao {
    private SqlSessionFactory sqlSessionFactory;
    public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
		this.sqlSessionFactory = sqlSessionFactory;
	}
	public SysConfig findById(Integer id) {
		System.out.println("findById");
		//1.创建SqlSession对象
		SqlSession sqlSession=
		sqlSessionFactory.openSession();
		//2.执行查询操作
		String statement=
		"com.jt.sys.dao.SysConfigDao.findById";
		SysConfig config=//此步骤底层会自动映射
		sqlSession.selectOne(statement,id);//selectList
		//4.释放资源
		sqlSession.close();
		//5.返回结果
		return config;
	}
}

//Spring->DataSource
//Spring-->SysConfigDaoImpl-->DataSource
//Spring-->SysConfigDaoImpl-->JdbcTemplate-->DataSource
//Controller-->XxxService-->XxxDao-->JdbcTemplate-->DataSource
//===============
//Spring-->DataSource
//Spring-->SqlSessionFactoryBean-->DataSource
//Spring-->SysConfigDaoImpl-->SqlSessionFactory-->DataSource









