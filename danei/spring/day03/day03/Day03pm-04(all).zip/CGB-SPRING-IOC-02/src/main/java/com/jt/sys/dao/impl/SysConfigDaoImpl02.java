package com.jt.sys.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.jt.sys.dao.SysConfigDao;
import com.jt.sys.entity.SysConfig;

public class SysConfigDaoImpl02 implements SysConfigDao {

	private JdbcTemplate jdbcTemplate;
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public SysConfig findById(Integer id) {
	    System.out.println("jdbcTemplate="+jdbcTemplate);
		String sql="select * from sys_configs where id=?";
	    return jdbcTemplate.queryForObject(sql,
	    		new Object[]{id},
	    		new RowMapper<SysConfig>(){
	    	    public SysConfig mapRow(ResultSet rs,
	    	    		int rowNum) throws SQLException {
	    		SysConfig cfg=new SysConfig();
	    		cfg.setId(rs.getInt("id"));
	    		cfg.setName(rs.getString("name"));
	    		cfg.setValue(rs.getString("value"));
	    		//.....
	    		return cfg;
	    	  }
	    });//一行记录映射为内存中的一个对象
	    
	}

}
