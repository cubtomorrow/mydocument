package com.jt.sys.service.impl;

import com.jt.sys.dao.SysConfigDao;
import com.jt.sys.entity.SysConfig;
import com.jt.sys.service.SysConfigService;

public class SysConfigServiceImpl implements SysConfigService {
	private SysConfigDao sysConfigDao;
	public void setSysConfigDao(SysConfigDao sysConfigDao) {
		this.sysConfigDao = sysConfigDao;
	}
	public SysConfig findById(Integer id) {
		//1.对参数进行有效性验证
		if(id==null||id<1)
		throw new IllegalArgumentException("id值无效");
		//2.基于Dao对象访问数据库
		SysConfig cfg=sysConfigDao.findById(id);
		if(cfg==null)
		throw new RuntimeException("没有找到对应记录");//ServiceException
		//3.返回数据
		return cfg;
	}

}
