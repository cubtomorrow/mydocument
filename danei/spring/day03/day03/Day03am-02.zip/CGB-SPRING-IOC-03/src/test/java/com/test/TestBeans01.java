package com.test;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.Test;
import org.mybatis.spring.SqlSessionFactoryBean;
public class TestBeans01 extends TestBase {
	 @Test
	 public void testSqlSessionFactory(){
		 SqlSessionFactory ssf=
		 ctx.getBean("sqlSessionFactory",SqlSessionFactory.class);
		 System.out.println(ssf);
		 //=======================(下面的了解)
		 SqlSessionFactoryBean ssfb=
		 ctx.getBean("&sqlSessionFactory",
				 SqlSessionFactoryBean.class);
		 System.out.println(ssfb);
	 }
}
