package day1002;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class Test1 {
	public static void main(String[] args) {
		System.out.println("�����ַ�����");
		String s = new Scanner(System.in).nextLine();
		System.out.println("���ҵ��Ӵ���");
		String t = new Scanner(System.in).nextLine();
		
		LinkedList<Integer> list = find(s, t);
		//�½�������
		Iterator<Integer> it = list.iterator();
		while(it.hasNext()) {
			Integer i = it.next();
			System.out.println(i);
		}

	}

	private static LinkedList<Integer> find(
			String s, String t) {
		LinkedList<Integer> list = 
				new LinkedList<>();
		
		int index=-1;//ÿ���ҵ���λ���±�
		while(true) {
			index = s.indexOf(t, index+1);
			if(index==-1) {
				break;
			}
			list.add(index);
		}
		return list;
	}
}





