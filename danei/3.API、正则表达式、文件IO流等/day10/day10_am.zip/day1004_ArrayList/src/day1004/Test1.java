package day1004;

import java.util.ArrayList;
import java.util.Iterator;

public class Test1 {
	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<>();
		list.add(999);
		list.add(222);
		list.add(777);
		list.add(111);
		list.add(555);
		list.add(999);
		list.add(888);
		list.add(333);
		System.out.println(list.size());
		System.out.println(list);
		System.out.println(
			list.remove(Integer.valueOf(999)));
		System.out.println(list);
		
		//�±����
		for(int i=0;i<list.size();i++) {
			Integer v = list.get(i);
			System.out.println(v);
		}
		//����������
		Iterator<Integer> it = list.iterator();
		while(it.hasNext()) {
			Integer v = it.next();
			System.out.println(v);
		}
		
		
	}
}




