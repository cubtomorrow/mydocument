package day1201;

import java.io.FileNotFoundException;
import java.io.RandomAccessFile;

public class Test2 {
	public static void main(String[] args) throws Exception {
		RandomAccessFile raf = 
		 new RandomAccessFile(
		 "d:/abc/f3", "rw");
		
		raf.write(97);//61
		raf.write(98);//62
		raf.write(99);//63
		raf.writeInt(97);//00 00 00 61
		raf.writeInt(98);//00 00 00 62
		raf.writeInt(99);//00 00 00 63
		raf.writeDouble(3.14);
		raf.writeChar('a');//00 61
		raf.writeChar('��');//4e 2d
		raf.writeByte(127);
		raf.writeBoolean(true);
		
		raf.seek(0);
		System.out.println(raf.read());
		System.out.println(raf.read());
		System.out.println(raf.read());
		System.out.println(raf.readInt());
		System.out.println(raf.readInt());
		System.out.println(raf.readInt());
		System.out.println(raf.readDouble());
		System.out.println(raf.readChar());
		System.out.println(raf.readChar());
		System.out.println(raf.readByte());
		System.out.println(raf.readBoolean());
		
		
		raf.close();
	}
}







