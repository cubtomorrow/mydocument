package day1105;

import java.io.File;
import java.util.Scanner;

public class Test1 {
	public static void main(String[] args) {
		System.out.println("����ɾ����Ŀ¼��");
		String s = new Scanner(System.in).nextLine();
		File dir = new File(s);
		if(! dir.isDirectory()) {
			System.out.println("����Ŀ¼");
			return;
		}
		
		boolean b = deleteDir(dir);
		if(b) {
			System.out.println("���");
		} else {
			System.out.println("ʧ��");
		}

	}

	private static boolean deleteDir(File dir) {
		File[] files = dir.listFiles();
		if(files == null) {
			return dir.delete();
		}
		
		for (File f : files) {
			if(f.isFile()) {
				if(! f.delete()) {
					return false;
				}
			} else {
				if(! deleteDir(f)) {
					return false;
				}
			}
		}
		
		return dir.delete();
	}
}







