package day1204;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Arrays;

public class Test2 {
	public static void main(String[] args) throws Exception {
		FileInputStream in;
		
		in = new FileInputStream("d:/abc/f4");
		//���ֽڶ�ȡ
		int b;
		while((b = in.read()) != -1) {
			System.out.println(b);
		}
		in.close();
		
		in = new FileInputStream("d:/abc/f4");      
		//������ȡ
		byte[] buff = new byte[5];
		int n;//һ��������
		while((n = in.read(buff)) != -1) {
			System.out.println(
			 n+"���� "+Arrays.toString(buff));
		}
		in.close();
		
		
	}
}









