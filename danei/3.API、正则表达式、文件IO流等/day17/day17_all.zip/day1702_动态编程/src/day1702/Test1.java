package day1702;

public class Test1 {
	public static void main(String[] args) {
		Runner.launch();
	}
}


