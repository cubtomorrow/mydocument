package day1701;

import java.lang.reflect.Method;
import java.util.Date;

public class Test4 {
	public static void main(String[] args) throws Exception {
		/*
		 * Date
		 *     getTime()
		 *     setTime(long)
		 */
		Date d = new Date();
		Class c = d.getClass();
		
		//��÷���
		Method getTime = 
		 c.getMethod("getTime");
		
		Method setTime = 
		 c.getMethod("setTime", long.class);
		
		//���÷���
		setTime.invoke(d, 900000000000L);
		System.out.println(d);
		
		Object r = getTime.invoke(d);
		System.out.println(r);
		
		
		
	}
}







