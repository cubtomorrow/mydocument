package day1401;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Test1 {
	public static void main(String[] args) {
		Thread t = new Thread() {
			@Override
			public void run() {
				SimpleDateFormat f = 
				 new SimpleDateFormat(
				 "HH:mm:ss.SSS");
				while(true) {
					String s = 
					 f.format(new Date());        
					System.out.println(s);
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {   
						//����ѭ��������run()����
						System.out.println(
						 "˭TMDͱ������");
						break;
					}
				}
			}
		};
		
		t.start();
		
		//main�߳�
		//���س������t�߳�
		new Scanner(System.in).nextLine();
		
		t.interrupt();
		
	}
}
