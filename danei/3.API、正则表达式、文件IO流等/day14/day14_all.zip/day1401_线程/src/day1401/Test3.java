package day1401;

import java.util.Arrays;

public class Test3 {
	static Object o1 = new Object();
	
	public static void main(String[] args) {
		char[] a = new char[5];

		new Thread() {
			@Override
			public void run() {
				char c = '*';
				while(true) {
					synchronized (a) {
						for (int i = 0; i < a.length; i++) {
							a[i] = c;
						}
					}
					c = (c=='*'?'-':'*');
				}
			}
		}.start();

		new Thread() {
			@Override
			public void run() {
				while(true) {
					synchronized (a) {
						System.out.println(
							Arrays.toString(a));
					}
				}
			}
		}.start();
	}
}
