package day1102;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Test2 {
	public static void main(String[] args) {
		try {
			f();
		} catch (ParseException e) {
			System.out.println("���ڸ�ʽ����");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("���ܴ����ļ�");
			e.printStackTrace();
		}
	}

	private static void f() throws ParseException, IOException {
		System.out.println("���ڣ�yyyy-MM-dd����");
		String s = new Scanner(System.in).nextLine();
		SimpleDateFormat f = 
		 new SimpleDateFormat("yyyy-MM-dd");
		Date d = f.parse(s);
		long t = d.getTime();
		// d:\4563456465.txt
		String path = "d:\\"+t+".txt";
		File file = new File(path);
		file.createNewFile();
		System.out.println("�Ѿ������ļ���"+path);
	}
}
