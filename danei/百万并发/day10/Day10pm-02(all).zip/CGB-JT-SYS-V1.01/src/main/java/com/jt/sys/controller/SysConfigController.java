package com.jt.sys.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/config/")
public class SysConfigController {
	  @RequestMapping("doConfigListUI")
	  public String doConfigListUI(){
		  return "sys/config_list";
	  }
}




