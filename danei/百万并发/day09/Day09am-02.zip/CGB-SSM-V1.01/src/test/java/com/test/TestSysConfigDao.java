package com.test;
import java.util.List;
import org.junit.Test;
import com.jt.sys.dao.SysConfigDao;
import com.jt.sys.entity.SysConfig;

public class TestSysConfigDao extends TestBase{
	@Test
	public void testFindPageObjects(){
		SysConfigDao dao=
		ctx.getBean(SysConfigDao.class);
		List<SysConfig> list=
		dao.findPageObjects("u",0, 2);
		for(SysConfig cfg:list){
		System.out.println(cfg.getName()+"="+cfg.getValue());
		}
	}
	@Test
	public void testGetRowCount(){
		SysConfigDao dao=
		ctx.getBean(SysConfigDao.class);
	    int rowCount=dao.getRowCount("u");
	    System.out.println(rowCount);
	}
}







