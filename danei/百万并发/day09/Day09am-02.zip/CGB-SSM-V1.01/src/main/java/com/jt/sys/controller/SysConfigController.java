package com.jt.sys.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.jt.common.annotation.HandlerMonitor;
import com.jt.common.vo.JsonResult;
import com.jt.common.vo.PageObject;
import com.jt.sys.entity.SysConfig;
import com.jt.sys.service.SysConfigService;


@Controller
@RequestMapping("/config/")
public class SysConfigController {//MVC
	@Autowired
	private SysConfigService sysConfigService;
	
	@RequestMapping("doConfigUI")
	public String doConfigUI(){
		return "config-ajax";
	}
	//400,客户端向服务端传递的数据格式不对
	//415,客户端向服务端传递的mediaType不对
	@RequestMapping(
	value="doFindPageObjects",
	method=RequestMethod.GET,
	produces="application/json;charset=utf-8")
	@ResponseBody
	@HandlerMonitor
	public JsonResult doFindPageObjects(
			String name,
			Integer pageCurrent){
		System.out.println("name="+name);
		//long startTime=System.nanoTime();
		PageObject<SysConfig> pageObject=
				sysConfigService.
		findPageObjects(name,pageCurrent);
		//long endTime=System.nanoTime();
		//System.out.println("totalTime="+(endTime-startTime));
		return new JsonResult(pageObject);
	}//将对象转换为json输出(底层借助fastjson库)
	//Controller-->service--->dao-->DB
/*	@ExceptionHandler(RuntimeException.class)
	@ResponseBody
	public String doRuntimeException(RuntimeException e){
		System.out.println("controller.doRuntimeException");
		return e.getMessage();
	}*/
}
