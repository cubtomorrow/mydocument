package com.jt.common.interceptor;

import java.lang.reflect.Method;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.jt.common.annotation.HandlerMonitor;

@Component //<bean id="" class=""/>
public class TimeInterceptor implements HandlerInterceptor {//ControllerInterceptor
	public TimeInterceptor() {
		System.out.println("TimeInterceptor()");
	}
	@Override
	public boolean preHandle(
			HttpServletRequest request, 
			HttpServletResponse response, Object handler)
			throws Exception {
		//System.out.println("pre.handler="+handler.getClass().getName());
		//此对象中封装了控制层要执行的方法信息
		HandlerMethod hMethod=(HandlerMethod)handler;
		Method method=hMethod.getMethod();
		//判定方法上有没有HandlerMonitor注解,有则进行
		if(method.isAnnotationPresent(HandlerMonitor.class)){
		String methodName=method.getName();
		long startTime=System.nanoTime();
		System.out.println(methodName+" start time is "+ startTime);
		//切记不要将此变量以属性的形式写到方法外面.
		request.setAttribute("startTime",startTime);
		}
		System.out.println("preHandle");
		return true;//true 放行
	}
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response,
			Object handler,
			ModelAndView modelAndView) throws Exception {
		System.out.println("postHandle");
	}
	/**视图渲染结束以后执行*/
	@Override
	public void afterCompletion(HttpServletRequest request, 
			HttpServletResponse response,
			Object handler, Exception ex)
			throws Exception {
		System.out.println("afterCompletion");
		//业务实现(监控案例)
		//1.获取方法对象
		Method method=
		((HandlerMethod)handler).getMethod();
		String methodName=method.getName();
		//2.假如方法上有HandlerMonitor注解则记录方法结束的时间以及业务执行时长
		if(method.isAnnotationPresent(
				HandlerMonitor.class)){
		long endTime=System.nanoTime();
		System.out.println(methodName+" end time is "+endTime);
		long startTime=
		(Long)request.getAttribute("startTime");
		System.out.println("totalTime="+(endTime-startTime));
		}
	}

}
