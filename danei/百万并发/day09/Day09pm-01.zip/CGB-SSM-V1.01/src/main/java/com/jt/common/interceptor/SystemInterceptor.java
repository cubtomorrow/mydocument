package com.jt.common.interceptor;

import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
@Component
public class SystemInterceptor extends HandlerInterceptorAdapter {
   /**
    * 在此方法中基于请求时间
    * 决定请求被放行还是拦截
    * 1)9点之前拦截
    * 2)17点之后拦截
    * 其它时间都放行.
    */
   @Override
   public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
		throws Exception {
	//获取日历对象
	Calendar c=Calendar.getInstance();
	//获取当前时间的毫秒数
	long currentTime=c.getTimeInMillis();
	//获取今天的9时的时间(毫秒)
	c.set(Calendar.HOUR_OF_DAY, 9);
	c.set(Calendar.MINUTE, 0);
	c.set(Calendar.SECOND, 0);
	c.set(Calendar.MILLISECOND, 0);
	long time9=c.getTimeInMillis();
	//获取今天的17时的时间(毫秒)
	c.set(Calendar.HOUR_OF_DAY, 18);
	long time17=c.getTimeInMillis();
    if(currentTime<time9||currentTime>time17){
		System.out.println("系统维护时间");
		return false;//拦截
	}
	return true;//放行
   }
}
