package com.test;
import org.junit.Test;

import com.jt.common.vo.PageObject;
import com.jt.sys.entity.SysConfig;
import com.jt.sys.service.SysConfigService;
public class TestSysConfigService extends TestBase{
	@Test
	public void testFindPageObjects(){
		SysConfigService sysConfigService=
		ctx.getBean("sysConfigService",
				SysConfigService.class);
		PageObject<SysConfig> pageObject=
		sysConfigService.findPageObjects("u",1);
		System.out.println(
		pageObject.getPageCount());
	}
}
