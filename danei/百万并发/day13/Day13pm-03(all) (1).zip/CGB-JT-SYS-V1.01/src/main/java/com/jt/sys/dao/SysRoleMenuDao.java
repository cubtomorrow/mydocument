package com.jt.sys.dao;
/**
 * 为什么写此DAO?
 * 
 * 市场规则:
 * 1)一个表对应一个映射文件
 * 2)一个映射文件对应一个DAO接口
 */
public interface SysRoleMenuDao {
	/**基于菜单ID删除角色菜单关系表数据*/
	int deleteObjectsByMenuId(Integer menuId);
}
