package com.jt.sys.service;

import com.jt.common.vo.PageObject;
import com.jt.sys.entity.SysConfig;

public interface SysConfigService {
  /***
   * 依据分页查询配置信息
   * @param name 
   * @param pageCurrent
   * @return
   */
  PageObject<SysConfig> findPageObjects(
		  String name,Integer pageCurrent);
}





