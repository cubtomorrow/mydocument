package com.jt.sys.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jt.common.exception.ServiceException;
import com.jt.common.vo.PageObject;
import com.jt.sys.dao.SysConfigDao;
import com.jt.sys.entity.SysConfig;
import com.jt.sys.service.SysConfigService;
@Service
public class SysConfigServiceImpl implements SysConfigService{
	@Autowired
	private SysConfigDao sysConfigDao;
	@Override
	public PageObject<SysConfig> findPageObjects(String name, Integer pageCurrent) {
		//1.判定参数的有效性
		if(pageCurrent==null||pageCurrent<1)
		throw new IllegalArgumentException("页码值不正确");
		//2.查询总记录数
		int rowCount=sysConfigDao.getRowCount(name);
		//3.验证总记录数
		if(rowCount==0)
	    throw new ServiceException("没有找到对应记录");
		//4.分页查询当前页记录
		Integer pageSize=2;
		Integer startIndex=(pageCurrent-1)*pageSize;
		List<SysConfig> records=
		sysConfigDao.findPageObjects(name,
				startIndex, pageSize);
		//5.封装查询结果
		PageObject<SysConfig> po=new PageObject<>();
		po.setRecords(records);
		po.setRowCount(rowCount);
		po.setPageCount((rowCount-1)/pageSize+1);
		po.setPageCurrent(pageCurrent);
		po.setPageSize(pageSize);
		return po;
	}
}







