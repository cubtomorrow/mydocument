package com.jt.sys.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.jt.sys.entity.SysConfig;

public interface SysConfigDao {
     /**
      * 查询当前页数据
      * @param name  查询条件
      * @param startIndex 当前页数据的起始位置
      * @param pageSize 页面大小
      * @return
      */
	 List<SysConfig> findPageObjects(
			 @Param("name")String name,
			 @Param("startIndex")Integer startIndex,
			 @Param("pageSize")Integer pageSize);
	 
	 /**
	  * 依据条件统计总记录数
	  * @param name
	  * @return
	  */
	 int getRowCount(@Param("name")String name);
}
