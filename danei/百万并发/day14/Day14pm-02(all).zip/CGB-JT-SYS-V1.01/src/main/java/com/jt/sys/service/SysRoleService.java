package com.jt.sys.service;
import com.jt.common.vo.PageObject;
import com.jt.sys.entity.SysRole;
public interface SysRoleService {
	
	 /**
	  * 保存角色以及角色与菜单的关系数据
	  * @param entity
	  * @param menuIds
	  * @return
	  */
	 int saveObject(SysRole entity,Integer[] menuIds);
	
	  /**
	   * 删除角色信息
	   * @param id
	   * @return
	   */
	  int deleteObject(Integer id);
	
	  /**
	   * 分页查询当前页记录以及总记录数
	   * @param name
	   * @param pageCurrent 当前页页码
	   * @return
	   */
	  PageObject<SysRole> findPageObjects(
			  String name,
			  Integer pageCurrent);
}






