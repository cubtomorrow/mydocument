package com.jt.sys.dao;
/**
 * 用于操作用户和角色的关系表数据
 */
public interface SysUserRoleDao {
	/**
	 * 基于角色id删除角色和用户在中间中的关系数据
	 * @param roleId
	 * @return
	 */
	int deleteObjectsByRoleId(Integer roleId);
}
