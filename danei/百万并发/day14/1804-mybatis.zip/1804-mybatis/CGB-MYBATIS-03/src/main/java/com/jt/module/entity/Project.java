package com.jt.module.entity;
import java.io.Serializable;
import java.util.Date;
public class Project implements Serializable{//ctrl+shift+o:快速引入某个包中的类 
	private static final long serialVersionUID = -5325788268980146026L;
	private Integer id;
	private String name;
	private String note;
	private Date createdTime;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		//System.out.println("setId");
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	@Override
	public String toString() {
		return "Project [id=" + id + ", name=" + name + ", note=" + note + ", createdTime=" + createdTime + "]";
	}
}
