package com.jt.module.dao;

import java.util.Map;

import com.jt.module.entity.Order;
import com.jt.module.vo.OrderResult;

public interface OrderDao {
	int insertObject(Order entity);
	/**
	 * 基于订单id查询订单信息以及订单
	 * 关联的项目信息,并将结果封装到map
	 * 对象(此次查询执行表关联查询.)
	 * @param id
	 * @return
	 */
	 Map<String,Object> 
     findObjectById(String id);
	 /**
	  * 基于订单id查询订单信息以及订单
	  * 关联的项目信息,并将结果封装到VO(Value Object)
	  * 对象(此次查询执行表关联查询.)
	  * @param id
	  * @return
	  */
	OrderResult
	findOrderResultById(String id);
	
	/**
	 * 基于订单id查询订单信息以及订单
	 * 关联的项目信息,并将结果封装到VO(Value Object)
	 * 对象(通过多次查询实现)
	 * @param id
	 * @return
	 */
	OrderResult
	findOrderResultWithId(String id);

}
