package com.test;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import com.jt.module.dao.ProjectDao;
import com.jt.module.entity.Project;
public class TestProjectDao01 extends TestBase {
	 @Test
	 public void testDeleteObject(){
		 //1.open session
		 SqlSession session =factory.openSession();
		 //2.execute insert
		 ProjectDao dao=
		 session.getMapper(ProjectDao.class);
		 int rows=dao.deleteObject(2,3,4);
		 //session.commit();
		 System.out.println("rows="+rows);
		 //3.close session
		 session.close();
	 }
	 @Test
	 public void testUpdateObject(){
		 //1.open session
		 SqlSession session =factory.openSession();
		 //2.execute insert
		 ProjectDao dao=
		 session.getMapper(ProjectDao.class);
		 Project p=new Project();
		 //p.setId(2);
		 p.setName("project-d");
		 p.setNote("project-note-d");
		 int rows=dao.updateObject(p);
		 session.commit();
		 System.out.println("rows="+rows);
		 //3.close session
		 session.close();
	 }
	 
	 @Test
	 public void testInsertObject(){
		 //1.open session
		 SqlSession session =factory.openSession();
		 //2.execute insert
		 ProjectDao dao=
				 session.getMapper(ProjectDao.class);
		 Project p=new Project();
		 p.setName("project-dddddd");
		 p.setNote("project-note-ddddddd");
		 p.setCreatedTime(new Date());
		 int rows=dao.insertObject(p);
		 System.out.println("p.id="+p.getId());
		 session.commit();
		 System.out.println("rows="+rows);
		 //3.close session
		 session.close();
	 }
	 @Test
	 public void testInsertObjects(){
		 //1.open session
		 SqlSession session =factory.openSession();
		 //2.execute insert
		 ProjectDao dao=session.getMapper(ProjectDao.class);
		 List<Project> list=new ArrayList<Project>();
		 for(int i=4;i<=6;i++){
		 Project p=new Project();
		 p.setName("project-dddddd-"+i);
		 p.setNote("project-note-ddddddd-"+i);
		 p.setCreatedTime(new Date());
		 list.add(p);
		 }
		 int rows=dao.insertObjects(list);
		 session.commit();
		 System.out.println("rows="+rows);
		 System.out.println(list);
		 //3.close session
		 session.close();
	 }
	 
	 @Test
	 public void testFindPageObjects(){
		 //1.open session
		 SqlSession session=
		 factory.openSession();
		 //2.execute query
		 //2.1 get mapper
		 ProjectDao dao=
		 session.getMapper(ProjectDao.class);
		 //2.2 execute dao method
		 List<Project> list=dao.findPageObjects("p",0,2);
		 //2.3 print result
		 for(Project pro:list){
		 System.out.println(pro);
		 }
		 //3.close session
		 session.close();
	 }
	 
	 
	 @Test
	 public void testFindObjectById(){
		 //1.open session
		 SqlSession session=
				 factory.openSession();
		 //2.execute query
		 //2.1 get mapper
		 ProjectDao dao=
				 session.getMapper(ProjectDao.class);
		 //2.2 execute dao method
		 Project pro=dao.findObjectById(2);
		 //2.3 print result
		 System.out.println(pro);
		 //3.close session
		 session.close();
	 }
	 
	 
	 @Test
	 public void testFindObjects(){//Executor-->CachingExecutor-->SimpleExecutor-->jdbc
		 //1.create session
		 SqlSession session=
		 factory.openSession();
		 //2.execute query
		 //session.selectList(statement, parameter);
		 //2.1 获取接口实现类对象
		 ProjectDao dao=//等号右边指向的是一个代理对象(课后了解代理模式)
		 session.getMapper(ProjectDao.class);//ProjectDaoMapper.xml
		 //System.out.println(dao.getClass().getName());
		 //2.2执行查询操作
		 List<Project> list=
		 dao.findObjects("id","desc");//create connection,statement,....
		 //2.3处理查询结果
		 for(Project p:list){
			System.out.println(p);
		 }
		 //3.close session
		 session.close();
	 }
}






