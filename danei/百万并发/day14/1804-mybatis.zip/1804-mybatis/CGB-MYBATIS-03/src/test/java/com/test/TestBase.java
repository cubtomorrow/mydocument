package com.test;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;

public class TestBase {
     protected SqlSessionFactory factory;
	 @Before
	 public void init() throws IOException{
		 InputStream in=
		 //new FileInputStream("src/main/resources/mybatis-configs.xml");
		 //从类路径下读取配置文件
		 Resources.getResourceAsStream("mybatis-configs.xml");
		 factory=new SqlSessionFactoryBuilder()
		.build(in);
	 }
}
