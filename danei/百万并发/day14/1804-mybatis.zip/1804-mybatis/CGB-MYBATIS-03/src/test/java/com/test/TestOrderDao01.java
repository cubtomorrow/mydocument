package com.test;

import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import com.jt.module.dao.OrderDao;
import com.jt.module.entity.Order;
import com.jt.module.vo.OrderResult;

public class TestOrderDao01 extends TestBase{
	 @Test
	 public void testFindObjectById(){
		 SqlSession session=
	     factory.openSession();	 
		 OrderDao dao=
		 session.getMapper(OrderDao.class);
		 String id="1f1b873c899f11e88ee01f3bcb4a1279";
		 Map<String,Object> map=
		 dao.findObjectById(id);
		 System.out.println(map);
		 session.close();
	 }
	 @Test
	 public void testFindOrderResultById(){
		 SqlSession session=
				 factory.openSession();	 
		 OrderDao dao=
				 session.getMapper(OrderDao.class);
		 String id="1f1b873c899f11e88ee01f3bcb4a1279";
		 OrderResult result=
				 dao.findOrderResultById(id);
		 System.out.println(result);
		 session.close();
	 }
	 @Test
	 public void testFindOrderResultWithId(){
		 SqlSession session=
				 factory.openSession();	 
		 OrderDao dao=
		 session.getMapper(OrderDao.class);
		 String id="1f1b873c899f11e88ee01f3bcb4a1279";
		 OrderResult result=
				 dao.findOrderResultWithId(id);
		 System.out.println("orderId="+result.getId());
		 //System.out.println("projectName="+result.getProject().getName());
		 //System.out.println(result);
		 session.close();
	 }
	 
	 @Test
	 public void testInsertObject(){
		 //1.open session
		 SqlSession session=
		 factory.openSession();
		 //2.execute insert 
		 OrderDao dao=
		 session.getMapper(OrderDao.class);
		 Order o=new Order();
		 o.setState(0);
		 o.setPrice(100.1d);
		 o.setProjectId(3);
		 int rows=dao.insertObject(o);
		 session.commit();
		 System.out.println("rows="+rows);
		 System.out.println(o.getId());
		 //3.close session
		 session.close();
	 }
}



