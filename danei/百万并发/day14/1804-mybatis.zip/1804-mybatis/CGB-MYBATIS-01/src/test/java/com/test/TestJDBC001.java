package com.test;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
public class TestJDBC001 {
	@Test
	public void testFindObjects02()throws Exception{
		Connection conn=null;
		Statement stmt =null;
		ResultSet rs=null;
		String sql="select * from projects";
		Class.forName("com.mysql.jdbc.Driver");
		conn=DriverManager.getConnection(
			"jdbc:mysql:///cgbmybatis",
				"root",
				"root");
		stmt = conn.createStatement();
		rs=stmt.executeQuery(sql);
		
		//获取结结果集对应的元数据对象
		ResultSetMetaData rsmd=
		rs.getMetaData();
		
		List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
		while(rs.next()){//行映射(一行记录映射为一个map对象)
		 Map<String,Object> map=new HashMap<String, Object>();
		 int count=rsmd.getColumnCount();
		 for(int i=1;i<=count;i++){
			 map.put(rsmd.getColumnLabel(i),//key
					 rs.getObject(i));
		 }
		 System.out.println(map);
		 list.add(map);
		}
		
		rs.close();
		stmt.close();
		conn.close();
	}
	@Test
	public void testFindObjects01()throws Exception{
		Connection conn=null;
		Statement stmt =null;
		ResultSet rs=null;
		String sql="select * from projects";
		Class.forName("com.mysql.jdbc.Driver");
		conn=DriverManager.getConnection(
			"jdbc:mysql:///cgbmybatis",
				"root",
				"root");
		stmt = conn.createStatement();
		rs=stmt.executeQuery(sql);
		List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
		while(rs.next()){//行映射(一行记录映射为一个map对象)
		 Map<String,Object> map=new HashMap<String, Object>();
		 map.put("id", rs.getInt("id"));
		 map.put("name",rs.getString("name"));
		 map.put("note",rs.getString("note"));
		 map.put("createdTime", rs.getTimestamp("createdTime"));
		 list.add(map);
		}
		rs.close();
		stmt.close();
		conn.close();
	}
}
