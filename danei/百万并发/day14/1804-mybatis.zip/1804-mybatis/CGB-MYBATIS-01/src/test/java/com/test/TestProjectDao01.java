package com.test;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

public class TestProjectDao01 {
	private SqlSessionFactory factory;
	/**创建SqlSessionFactory工厂*/
	@Before
	public void init()throws IOException{
		//step01 读取配置文件
		InputStream in=
		Resources.getResourceAsStream(
				"mybatis-configs.xml");
		//step02:构建SqlSessionFactoryBuilder对象
		SqlSessionFactoryBuilder sBuilder=
		new SqlSessionFactoryBuilder();
		//step02:SqlSessionFactoryBuilder基于读取
		//的配置文件信息构建factory对象
		factory=sBuilder.build(in);
		//System.out.println(factory.getClass().getName());
	}
	@Test
	public void testFindObjectById(){
		//1.open session
		SqlSession session=factory.openSession();
		//2.execute query
		String statement=
		"com.jt.module.dao.ProjectDao.findObjectById";
		Map<String,Object> map=
		session.selectOne(statement,1);
		System.out.println(map);
		//3.close session
		session.close();
	}
	@Test
	public void testFindPageObjects(){
		//1.open session
		SqlSession session=factory.openSession();
		//2.execute query
		String statement="com.jt.module.dao.ProjectDao.findPageObjects";
		List<Map<String,Object>> list=
		session.selectList(statement,
				new Object[]{1,2});
		System.out.println(list);
		//3.close session
		session.close();
	}
	@Test
	public void testFindPageProjects(){
		//1.open sesssion
		SqlSession session=
		factory.openSession();
		//2.execute query
		//2.1 定义statement
		String statement=
		"com.jt.module.dao.ProjectDao.findPageProjects";
		//2.2封装查询参数
		Map<String,Object> map=new HashMap<String, Object>();
		map.put("name", "a");//查询名字包含某个值的记录
		map.put("startIndex",0);
		map.put("pageSize", 2);
		//2.3输出查询结果
		List<Map<String,Object>> list=
		session.selectList(statement,map);
		for(Map<?,?> m:list){
			System.out.println(m);
		}
		//3.close session
		session.close();
	}
	@Test
	public void testFindObjects(){//alt+shift+x
		//1.创建SqlSession对象
		SqlSession session=
		factory.openSession();
		//2.访问数据库资源
		String statement=
		"com.jt.module.dao.ProjectDao.findObjects";
		List<Map<String,Object>> list=
		session.selectList(statement);
		for(Map<String,Object> map:list){
		  //一行记录对应一个map对象
		  System.out.println(map);
		}
		//3.释放SqlSession对象
		session.close();
	}
}







