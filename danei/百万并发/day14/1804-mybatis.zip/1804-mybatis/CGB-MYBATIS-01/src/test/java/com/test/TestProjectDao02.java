package com.test;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class TestProjectDao02 {
	private SqlSessionFactory factory;
	@Before
	public void init() throws IOException{
		factory=new SqlSessionFactoryBuilder().build(
		Resources.getResourceAsStream(
	    "mybatis-configs.xml"));
	}
	@Test
	public void testInsertObject(){
		//1.open session
		SqlSession session=factory.openSession(false);//默认为false，需要手动提交事务
		//2.execute sql operator
		//2.1 create statement
		String statement=
	    "com.jt.module.dao.ProjectDao.insertObject";
		//2.2 create params object
		Map<String,Object> paramMap=
	    new HashMap<String,Object>();
		paramMap.put("name", "project-e");
		paramMap.put("note", "project-note-e");
		paramMap.put("createdTime", new Date());
		//2.3 insert
		int rows=session.insert(statement,paramMap);
		session.commit();//openSession(false)
		System.out.println("insert.rows="+rows);
		//3.close session
		session.close();
	}
	@Test
	public void testUpdateObject(){
		//1.create session
		SqlSession session=factory.openSession();
		//2.execute update
		//2.1 create statement
	    String statement=
		"com.jt.module.dao.ProjectDao.updateObject";
		//2.2 create params object
		Map<String,Object> paramMap=
	    new HashMap<String,Object>();
		paramMap.put("name", "project-eeeffff");
		paramMap.put("note", "project-note-eeff");
		paramMap.put("id",6);
		int rows=session.update(statement, paramMap);
		session.commit();
		//断言测试法，测试实际值是否与期望值相等
		Assert.assertEquals(1,//期望值
				rows);//实际值
		System.out.println("rows="+rows);
		//3.close session
		session.close();
	}
	
	@Test
	public void testDeleteObject(){
		//1.create session
		SqlSession session=factory.openSession();
		//2.execute update
		//2.1 create statement
		String statement=
		"com.jt.module.dao.ProjectDao.deleteObject";
		int rows=session.delete(statement, 1);
		//断言测试法，测试实际值是否与期望值相等
		Assert.assertEquals(1,//期望值
				rows);//实际值
		session.commit();
		System.out.println("rows="+rows);
		//3.close session
		session.close();
	}
}







