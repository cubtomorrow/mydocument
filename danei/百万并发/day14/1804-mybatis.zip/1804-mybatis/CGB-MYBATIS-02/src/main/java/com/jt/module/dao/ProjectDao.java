package com.jt.module.dao;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.jt.module.entity.Project;
public interface ProjectDao {
	
	/**
	 * 基于id执行删除操作
	 * @param id
	 * @return
	 */
	int deleteObject(Integer id);
	
	/**
	 * 更新表中记录
	 * @param entity 封装了要更新的数据
	 * @return
	 */
	int updateObject(Project entity);
	
	/**
	 * 向表中插入一条记录
	 * @param entity
	 * @return
	 */
	int insertObject(Project entity);
	
	/**
	 * 分页查询
	 * @param name
	 * @param startIndex
	 * @param pageSize
	 * @return
	 */
	List<Project> findPageObjects(
			@Param("searchName")String name,//映射文件可以使用#{name}获取@Param注解定义的参数对应的值
			@Param("startIndex")Integer startIndex,
			@Param("pageSize")Integer pageSize);
	/**
	 * 基于id查询项目信息
	 */
	Project findObjectById(Integer id);
	
    /**
     * 查询所有的项目信息
     * @return
     */
	List<Project> findObjects();
	
	
	
}
