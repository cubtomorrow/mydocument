package com.jt.sys.dao;

import org.apache.ibatis.annotations.Param;

/**
 * 用于操作用户和角色的关系表数据
 */
public interface SysUserRoleDao {
	/**
	 * 基于角色id删除角色和用户在中间中的关系数据
	 * @param roleId
	 * @return
	 */
	int deleteObjectsByRoleId(Integer roleId);
	
	
	/**
	 * 负责将用户与角色的关系数据写入到数据库
	 * @param userId 用户id
	 * @param roleIds 多个角色id
	 * @return
	 */
	int insertObject(
			@Param("userId")Integer userId,
			@Param("roleIds")Integer[]roleIds);

	
	
}
