package com.tedu.request;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * ��ȡ�ͻ����Ļ�����Ϣ����ȡ����ͷ��Ϣ
 * 
 * @author: bjzhangsz
 * @time:  2018��7��26�� ����2:25:48
 */
public class RequestDemo1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//1.getRequestURL
		String url = request.getRequestURL()
							.toString();
		System.out.println("url="+url);
		
		//2.getRequestURI
		String uri = request.getRequestURI();
		System.out.println("uri="+uri);
		
		//3.getMethod
		String method = request.getMethod();
		System.out.println("method="+method);
		
		//4.getRemoteAddr
		String ip = request.getRemoteAddr();
		System.out.println("ip="+ip);
		
		//5.getContextPath
		String path = request.getContextPath();
		System.out.println("contextPath="+path);
		
		//response.sendRedirect(path+"/index.html");
		
		//6.getHeader(String headerName)
		String host = request.getHeader("host");
		System.out.println("host:"+host);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}





