package com.tedu;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author: bjzhangsz
 * @time:  2018��7��31�� ����2:05:55
 */
public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		
		String name = "������";
		int age = 18;
		
		
		response.getWriter().write("<!doctype html>");
		response.getWriter().write("<html>");
		response.getWriter().write("<head>");
		response.getWriter().write("<meta charset='utf-8'/>");
		response.getWriter().write("</head>");
		response.getWriter().write("<body>");
		response.getWriter().write("<p style='border:1px solid red'>");
		response.getWriter().write("����: "+name);
		response.getWriter().write("</p>");
		response.getWriter().write("<p style='border:1px solid red'>");
		response.getWriter().write("����: "+age);
		response.getWriter().write("</p>");
		response.getWriter().write("</body>");
		response.getWriter().write("</html>");
		
		
		
		
		response.getWriter().write("����:"+name);
		response.getWriter().write("����:"+age);
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}
