package cn.tedu.servlet;
import java.util.*;
import java.io.*;
import javax.servlet.*;
public class FirstServlet extends GenericServlet{
	public void service(ServletRequest req, ServletResponse res) throws ServletException, java.io.IOException{
		String dateStr = new Date().toLocaleString();
		res.getWriter().write(dateStr);
	}
}