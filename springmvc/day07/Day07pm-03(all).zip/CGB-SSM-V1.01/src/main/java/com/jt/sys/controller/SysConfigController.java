package com.jt.sys.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jt.common.vo.PageObject;
import com.jt.sys.entity.SysConfig;
import com.jt.sys.service.SysConfigService;

@Controller
@RequestMapping("/config/")
public class SysConfigController {//MVC
	@Autowired
	private SysConfigService sysConfigService;
	@RequestMapping("doFindPageObjects")
	@ResponseBody
	public PageObject<SysConfig> 
	       doFindPageObjects(String name,
	    		   Integer pageCurrent){
		return sysConfigService.
		findPageObjects(name,pageCurrent);
	}//将对象转换为json输出(底层借助fastjson库)
}
