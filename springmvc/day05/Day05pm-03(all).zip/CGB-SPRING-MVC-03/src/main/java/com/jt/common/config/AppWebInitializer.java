package com.jt.common.config;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;
/**
 * tomcat 启动时会自动加载此对象,
 * 并执行此对象的onStartUp方法
 * @author 速度
 */
public class AppWebInitializer 
     extends AbstractAnnotationConfigDispatcherServletInitializer {
	/*@Override
	public void onStartup(ServletContext servletContext) throws ServletException {
		//此方法中会自动注册前端控制器
		super.onStartup(servletContext);
		System.out.println("onStartUp");
	}*/
	@Override
	protected Class<?>[] getRootConfigClasses() {
		return null;//service,dao
	}
	/**如下方法中要加载MVC配置*/
	@Override
	protected Class<?>[] getServletConfigClasses() {
		//AppServletConfig相当于spring-configs.xml
		return new Class[]{AppServletConfig.class};
	}
	/**如下方法配置映射路径*/
	@Override
	protected String[] getServletMappings() {
		return new String[]{"*.do"};
	}

}
