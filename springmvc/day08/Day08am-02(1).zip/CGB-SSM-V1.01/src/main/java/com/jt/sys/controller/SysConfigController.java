package com.jt.sys.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jt.common.annotation.HandlerMonitor;
import com.jt.common.vo.PageObject;
import com.jt.sys.entity.SysConfig;
import com.jt.sys.service.SysConfigService;

@Controller
@RequestMapping("/config/")
public class SysConfigController {//MVC
	@Autowired
	private SysConfigService sysConfigService;
	
	@RequestMapping("doConfigUI")
	@ResponseBody
	public String doConfigUI(){
		return "config page";
	}
	
	@RequestMapping("doFindPageObjects")
	@ResponseBody
	@HandlerMonitor
	public PageObject<SysConfig> doFindPageObjects(String name,
	    		   Integer pageCurrent){
		//long startTime=System.nanoTime();
		PageObject<SysConfig> pageObject=
				sysConfigService.
		findPageObjects(name,pageCurrent);
		//long endTime=System.nanoTime();
		//System.out.println("totalTime="+(endTime-startTime));
		return pageObject;
	}//将对象转换为json输出(底层借助fastjson库)
}
