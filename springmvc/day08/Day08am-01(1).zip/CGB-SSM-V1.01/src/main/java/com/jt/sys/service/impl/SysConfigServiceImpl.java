package com.jt.sys.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jt.common.exception.ServiceException;
import com.jt.common.vo.PageObject;
import com.jt.sys.dao.SysConfigDao;
import com.jt.sys.entity.SysConfig;
import com.jt.sys.service.SysConfigService;

@Service //<bean id="" class="">
public class SysConfigServiceImpl implements SysConfigService {
    //IOC
	@Autowired
	private SysConfigDao sysConfigDao;
	@Override
	public PageObject<SysConfig> findPageObjects(
			     String name,//""
	    		 Integer pageCurrent) {
		//1.参数有效性验证(pageCurrent)
		if(pageCurrent==null||pageCurrent<1)
		throw new IllegalArgumentException("当前页码值无效");
		//2.基于name参数查询总记录数
		int rowCount=sysConfigDao.getRowCount(name);
		//3.对总记录数进行判定,假如值为0无需执行进行后续查询
		if(rowCount==0)
		throw new ServiceException("不存在对应记录");
		//4.依据条件查询当前页记录(List)
		//4.1定义页面大小
		int pageSize=2;
		//4.2计算当前页记录的起始位置
		int startIndex=(pageCurrent-1)*pageSize;
		//4.3从当前页起始位置查询当前页记录
		List<SysConfig> records=
		sysConfigDao.findPageObjects(
				name,startIndex,pageSize);
		//5.对查询的结果进行封装
		PageObject<SysConfig> pageObject=
	    new PageObject<>();
		pageObject.setRecords(records);
		pageObject.setRowCount(rowCount);
		pageObject.setPageSize(pageSize);
		pageObject.setPageCurrent(pageCurrent);
		//计算总页数
		//方法1
		/*
		int pageCount=rowCount/pageSize;//求整
		if(rowCount%pageSize!=0){
			pageCount++;
		}*/
		//方法2
		int pageCount=(rowCount-1)/pageSize+1;
		
		pageObject.setPageCount(pageCount);
		//6.返回结果
		return pageObject;
	}

}



