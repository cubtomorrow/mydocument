package memory;
public class TestMemory01 {
	public static void main(String[] args) {
		Integer[] array=new Integer[Integer.MAX_VALUE];
	}
}
