package com.jt.sys.service;

import com.jt.common.vo.PageObject;
import com.jt.sys.entity.SysConfig;

public interface SysConfigService {
     /**
      * 依据条件执行分页查询
      * @param name 查询条件
      * @param pageCurrent 当前页页码(要查询的那一页)
      * @return
      */
	 PageObject<SysConfig> findPageObjects(
			 String name,
			 Integer pageCurrent);
	 
	 
	 
}
