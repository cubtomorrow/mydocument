package com.jt.common.controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jt.common.vo.JsonResult;
/**
 * 全局异常处理类(需要使用@ControllerAdvice注解进行修饰)
 * 可以在此类中添加所有Controller中
 * 需要共享的异常处理方法
 */
@ControllerAdvice
public class GlobalExceptionHandler {
	/**
	 * @ExceptionHandler 此注解声明的方法
	 * 为一个异常处理方法
	 * @return Class[]
	 * 1)Spring MVC 如何识别这个方法是一个
	 * 异常处理方法?
	 * 2)Spring MVC 后端处理器的方法出现异常
	 * 底层会如何处理?
	 */
	@ExceptionHandler(Exception.class)
	@ResponseBody
	public JsonResult doHandleException(Exception e){
		//System.out.println("doHandleException");
		e.printStackTrace();
		
		/*JsonResult result=
		new JsonResult(e.getMessage());
		result.setState(0);
		return result;*/
		
		return new JsonResult(e);
	}
	@ExceptionHandler(RuntimeException.class)
	@ResponseBody
	public JsonResult doRuntimeException(RuntimeException e){
		//System.out.println("global.doRuntimeException");
		e.printStackTrace();
		return new JsonResult(e);
	}
}